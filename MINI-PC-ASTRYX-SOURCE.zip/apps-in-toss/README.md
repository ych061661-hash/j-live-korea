# J LIVE 앱인토스 미니앱

J LIVE의 공연 캘린더를 토스 안에서 제공하기 위한 별도 WebView 앱인토스 프로젝트입니다.

## 시작

```powershell
npm install
npm run dev
```

## 빌드

```powershell
npm run build
```

현재 `granite.config.ts`의 `appName`, `icon`, 브랜드 정보는 앱인토스 콘솔 등록값과 실제 공개 로고 URL에 맞춰 최종 확인해야 합니다.
