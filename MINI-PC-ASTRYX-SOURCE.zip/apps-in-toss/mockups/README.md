# J-LIVE UI/UX 목업

J-LIVE의 기존 다크 배경·라임 강조색과 공개 일정 데이터를 참고한 독립 목업입니다. 원본 페이지나 생성기는 수정하지 않습니다.

## 실행

`apps-in-toss/mockups/jlive-uiux` 디렉터리에서 실행합니다. 설치된 `apps-in-toss/node_modules`를 사용하므로 기존 앱의 진입점과 파일을 건드리지 않습니다.

```sh
npm run dev
```

새 환경에서는 먼저 `apps-in-toss`에서 `npm install`을 실행한 뒤 목업 폴더에서 위 명령을 실행하세요.

## 적용한 Astryx 구성

- `library` 페이지 템플릿의 페이지 프레임
- `Layout`, `LayoutHeader`, `LayoutContent`, `useCalendarNavigation`, `useCalendarDays`, `Card`, `List`, `ListItem`, `TextInput`, `Button`, `HStack`, `VStack`, `Theme`, `InternationalizationProvider`
- Astryx의 `ko-KR` 카탈로그를 연결해 달력과 보조기기 문구를 한국어로 표시
- 공식 채널 프로필 이미지 캐시를 목업 `public/assets`에 별도 복사

## 원본 메인 기본 흐름 반영

- 공연일·일반예매·선예매를 각각 켜고 끄는 달력 필터와 색상 범례
- 날짜별 공연 건수만큼 달력 점을 표시하고, 날짜를 누르면 해당 일정으로 이동
- 검색 결과, 날짜별 회차 목록, 공연별 이미지·가격·공식 출처·대표곡·상세 페이지 링크
- 다음 주말 공연 모음, 일정 공유, 소개·문의·개인정보·약관·수정 요청 링크
- 모바일에서는 주말 목록과 달력 필터가 세로로 재배치

`public/data/mockEvents.json`은 2026-11-16 기준 `confirmed` 일정 60건에 `festival-lineups.json`의 WONDERLIVET 2026 일정 1건을 더한 목업 전용 스냅샷입니다. 원더리벳은 11월 20·21·22일을 각각 달력에 표시하며 페스티벌 점·필터 색을 별도로 사용합니다. 후보·보류 항목과 원본 운영 파일은 수정하지 않았습니다. 목업 밖의 실시간 변경은 자동 동기화되지 않습니다. 아티스트 이미지는 목업에 이미 포함된 이미지 또는 자체 그래픽 대체물을 사용하며, 권리 확인 상태를 뜻하지 않습니다.

달력 점과 필터는 Astryx의 기본 Calendar 마커 기능에 의존하지 않고 커스텀 월 뷰로 구현했습니다. 판매 상태는 소스 데이터가 제공하는 범위만 사용합니다.
