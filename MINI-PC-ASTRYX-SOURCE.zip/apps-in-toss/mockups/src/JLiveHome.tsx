import {useEffect, useMemo, useState} from 'react';
import {Button} from '@astryxdesign/core/Button';
import {
  useCalendarDays,
  useCalendarNavigation,
  type ISODateString,
} from '@astryxdesign/core/Calendar';
import {Card} from '@astryxdesign/core/Card';
import {Layout, LayoutContent, LayoutHeader} from '@astryxdesign/core/Layout';
import {List, ListItem} from '@astryxdesign/core/List';
import {TextInput} from '@astryxdesign/core/TextInput';
import {HStack, VStack} from '@astryxdesign/core/Stack';
import {Theme} from '@astryxdesign/core/theme';
import {InternationalizationProvider} from '@astryxdesign/core/i18n';
import koKR from '@astryxdesign/core/locales/ko-KR.generated.js';
import {jliveMockupTheme} from './themes/jlive-mockup/jliveMockupTheme';

type Concert = {
  id: string;
  artist: string;
  festivalDates?: ISODateString[];
  festivalPageUrl?: string;
  image?: string;
  posterImage?: string;
  isFestival?: boolean;
  date: ISODateString;
  time: string;
  venue: string;
  price?: number;
  seatPrices?: Array<{name: string; price: number; priceCurrency?: string}>;
  image?: string;
  ticketUrl?: string;
  ticketDate?: string;
  ticketTime?: string;
  presaleDate?: string;
  presaleTime?: string;
  ticketLabel?: string;
  ticketVendor?: string;
  scheduleChecked?: string;
  priceChecked?: string;
  sources?: string[];
  songs?: Array<{title: string; url: string}>;
  verifiedAt?: string;
};

type ScheduleKind = 'concert' | 'ticket' | 'presale' | 'festival';
type ScheduleEntry = {concert: Concert; kind: ScheduleKind; date: ISODateString};
const SCHEDULE_TYPES: Array<{kind: ScheduleKind; label: string}> = [
  {kind: 'concert', label: '공연일'},
  {kind: 'ticket', label: '일반예매'},
  {kind: 'presale', label: '선예매'},
  {kind: 'festival', label: '페스티벌'},
];

const makeScheduleEntries = (concerts: Concert[]): ScheduleEntry[] => concerts.flatMap(concert => [
  ...(concert.isFestival && concert.festivalDates?.length
    ? concert.festivalDates.map(date => ({concert, kind: 'festival' as const, date}))
    : [{concert, kind: 'concert' as const, date: concert.date}]),
  ...(concert.ticketDate ? [{concert, kind: 'ticket' as const, date: concert.ticketDate as ISODateString}] : []),
  ...(concert.presaleDate ? [{concert, kind: 'presale' as const, date: concert.presaleDate as ISODateString}] : []),
]);

type RawMockEvent = {
  id: string; artist: string; genre?: string; concertDate: ISODateString; time?: string; venue: string;
  festivalDates?: ISODateString[]; festivalPageUrl?: string; image?: string; posterImage?: string; eventType?: 'festival';
  presaleDate?: string; presaleTime?: string; ticketDate?: string; ticketTime?: string; ticketLabel?: string;
  vendor?: string; vendorUrl?: string; songs?: Array<[string, string, string]>; sources?: string[];
  verifiedAt?: string; scheduleVerifiedAt?: string; priceVerifiedAt?: string;
  seatPrices?: Array<{name: string; price: number; priceCurrency?: string}>; price?: number;
};

const localArtistImages: Array<[string, string]> = [
  ['kazumi', '/assets/kazumi.jpg'], ['yuki kajiura', '/assets/yuki-kajiura.jpg'],
  ['ellegarden', '/assets/ellegarden.jpg'], ['homecomings', '/assets/homecomings.jpg'],
  ['sunny day service', '/assets/sunny-day-service.jpg'], ['yuuri', '/assets/yuuri.jpg'],
  ['kana-boon', '/assets/kana-boon.jpg'],
];

const artistImage = (artist: string) => {
  const normalized = artist.toLocaleLowerCase();
  return localArtistImages.find(([name]) => normalized.includes(name))?.[1];
};

const mapMockEvents = (events: RawMockEvent[]): Concert[] => events.map(event => ({
    id: event.id,
    artist: event.artist,
    festivalDates: event.festivalDates,
    festivalPageUrl: event.festivalPageUrl,
    posterImage: event.posterImage,
    isFestival: event.eventType === 'festival',
    date: event.concertDate,
    time: event.time ?? '',
    venue: event.venue,
    price: event.price,
    seatPrices: event.seatPrices,
    image: event.image ?? artistImage(event.artist),
    ticketUrl: event.vendorUrl,
    ticketDate: event.ticketDate,
    ticketTime: event.ticketTime,
    ticketLabel: event.ticketLabel,
    presaleDate: event.presaleDate,
    presaleTime: event.presaleTime,
    ticketVendor: event.vendor,
    sources: event.sources,
    songs: event.songs?.map(([title, _duration, url]) => ({title, url})),
    verifiedAt: event.verifiedAt,
    scheduleChecked: event.scheduleVerifiedAt,
    priceChecked: event.priceVerifiedAt,
  })).sort((left, right) => left.date.localeCompare(right.date) || left.time.localeCompare(right.time));

const formatDate = (value: string) =>
  new Intl.DateTimeFormat('ko-KR', {
    timeZone: 'Asia/Seoul',
    month: 'long',
    day: 'numeric',
    weekday: 'short',
  }).format(new Date(`${value}T00:00:00+09:00`));

const formatCompactDate = (value: string) => {
  const date = new Date(`${value}T00:00:00+09:00`);
  const parts = new Intl.DateTimeFormat('ko-KR', {
    timeZone: 'Asia/Seoul', month: '2-digit', day: '2-digit', weekday: 'short',
  }).formatToParts(date);
  const part = (type: string) => parts.find(item => item.type === type)?.value ?? '';
  return `${part('month')}.${part('day')} ${part('weekday')}`;
};

const formatSeriesDates = (dates: ISODateString[]) => {
  const sorted = [...new Set(dates)].sort();
  if (sorted.length < 2) return sorted.map(formatCompactDate).join(' · ');
  const isContinuous = sorted.every((date, index) => index === 0 || addDays(sorted[index - 1], 1) === date);
  const weekdays = sorted.map(date => formatCompactDate(date).split(' ')[1]).join('·');
  return isContinuous
    ? `${sorted[0].slice(5).replace('-', '.')}–${sorted[sorted.length - 1].slice(5).replace('-', '.')} ${weekdays}`
    : sorted.map(formatCompactDate).join(' · ');
};

const formatCompactTime = (value: string) => {
  const match = value.match(/^(오전|오후|낮)\s*(\d{1,2}):(\d{2})$/);
  if (!match) return value;
  let hour = Number(match[2]);
  if (match[1] === '오후' && hour < 12) hour += 12;
  if (match[1] === '오전' && hour === 12) hour = 0;
  return `${String(hour).padStart(2, '0')}:${match[3]}`;
};

const formatPrice = (value?: number) => value ? `${value.toLocaleString('ko-KR')}원` : '가격 미확인';

const formatPriceSummary = (concert: Concert) => {
  const prices = (concert.seatPrices ?? []).filter(item => item.priceCurrency === 'KRW').map(item => item.price);
  if (!prices.length) return formatPrice(concert.price);
  const minimum = Math.min(...prices);
  const maximum = Math.max(...prices);
  return minimum === maximum ? formatPrice(minimum) : `최저 ${formatPrice(minimum)}부터`;
};

const formatAuditDate = (value?: string) =>
  value ? value.replaceAll('-', '.') : '미확인';

const createArtistArtwork = (artist: string) => {
  const initials = artist.split(/\s|&/).filter(Boolean).map(part => part[0]).slice(0, 2).join('');
  const label = artist.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 240"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#d6ff3f"/><stop offset="1" stop-color="#64d8c5"/></linearGradient></defs><rect width="240" height="240" rx="32" fill="#17191a"/><circle cx="194" cy="40" r="68" fill="url(#g)" opacity=".22"/><path d="M0 188 240 72v168H0Z" fill="url(#g)" opacity=".12"/><text x="22" y="133" fill="#d6ff3f" font-family="Arial,sans-serif" font-size="72" font-weight="800">${initials}</text><text x="22" y="207" fill="#f4f5f2" font-family="Arial,sans-serif" font-size="17" font-weight="700" textLength="196" lengthAdjust="spacingAndGlyphs">${label}</text></svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
};

const kstDateKey = (date = new Date()) => {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul', year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(date);
  const part = (type: string) => parts.find(item => item.type === type)?.value ?? '';
  return `${part('year')}-${part('month')}-${part('day')}` as ISODateString;
};

const addDays = (key: string, days: number) => {
  const date = new Date(`${key}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10) as ISODateString;
};

const formatCountdown = (date: ISODateString, today = kstDateKey()) => {
  const difference = Math.round((Date.parse(`${date}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) / 86_400_000);
  return difference === 0 ? 'D-DAY' : difference > 0 ? `D-${difference}` : `D+${Math.abs(difference)}`;
};

const nextConcertDate = (concert: Concert, today: ISODateString) =>
  concert.isFestival && concert.festivalDates?.length
    ? [...concert.festivalDates].filter(date => date >= today).sort()[0]
    : concert.date >= today ? concert.date : undefined;

function ConcertCalendar({
  entries,
  enabledTypes,
  selectedDate,
  onSelectDate,
  onToggleType,
}: {
  entries: ScheduleEntry[];
  enabledTypes: Set<ScheduleKind>;
  selectedDate: ISODateString | null;
  onSelectDate: (date: ISODateString) => void;
  onToggleType: (kind: ScheduleKind) => void;
}) {
  const {
    monthYearLabel,
    visibleCalendarMonths,
    navigateMonth,
  } = useCalendarNavigation({initialValue: selectedDate ? `${selectedDate.slice(0, 7)}-01` : '2026-11-01'});
  const {weeks, dayNames} = useCalendarDays({
    ...visibleCalendarMonths[0],
    weekStartsOn: 0,
    hasVariableRowCount: true,
  });
  const entriesByDate = entries.reduce<Map<ISODateString, Record<ScheduleKind, number>>>((counts, entry) => {
    const dayCounts = counts.get(entry.date) ?? {concert: 0, ticket: 0, presale: 0, festival: 0};
    dayCounts[entry.kind] += 1;
    counts.set(entry.date, dayCounts);
    return counts;
  }, new Map());
  return (
    <div className="event-calendar" aria-label={`${monthYearLabel} 공연 달력`}>
      <div className="event-calendar-nav">
        <Button label="이전 달" onClick={() => navigateMonth(-1)} variant="secondary" size="sm" />
        <h4 aria-live="polite">{monthYearLabel}</h4>
        <Button label="다음 달" onClick={() => navigateMonth(1)} variant="secondary" size="sm" />
      </div>
      <table className="event-calendar-grid" aria-label={`${monthYearLabel} 날짜별 공연`}>
        <thead>
          <tr>{dayNames.map(name => <th key={name} scope="col">{name}</th>)}</tr>
        </thead>
        <tbody>
          {weeks.map((week, weekIndex) => (
            <tr key={`${monthYearLabel}-${weekIndex}`}>
              {week.map(day => {
                if (day.isOutside) {
                  return <td className="is-outside" key={day.iso} aria-hidden="true" />;
                }
                const counts = entriesByDate.get(day.iso) ?? {concert: 0, ticket: 0, presale: 0, festival: 0};
                const dayCount = SCHEDULE_TYPES.filter(({kind}) => enabledTypes.has(kind)).reduce((sum, {kind}) => sum + counts[kind], 0);
                const dayLabels = SCHEDULE_TYPES.filter(({kind}) => enabledTypes.has(kind) && counts[kind] > 0)
                  .map(({kind, label}) => `${label} ${counts[kind]}건`).join(', ');
                const isSelected = selectedDate === day.iso;
                const fullDate = new Intl.DateTimeFormat('ko-KR', {
                  timeZone: 'Asia/Seoul',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  weekday: 'long',
                }).format(new Date(`${day.iso}T12:00:00+09:00`));

                return (
                  <td key={day.iso}>
                    <button
                      className={`event-calendar-day${isSelected ? ' is-selected' : ''}`}
                      type="button"
                      aria-label={`${fullDate}${dayCount ? `, ${dayLabels}` : ''}`}
                      aria-pressed={isSelected}
                      onClick={() => onSelectDate(day.iso)}>
                      <span>{day.dayNumber}</span>
                      {dayCount > 0 && (
                        <span className="event-calendar-dots" aria-hidden="true">
                          {SCHEDULE_TYPES.filter(({kind}) => enabledTypes.has(kind)).flatMap(({kind}) =>
                            Array.from({length: Math.min(counts[kind], 4)}, (_, index) => (
                              <span className={`event-calendar-dot dot-${kind}`} key={`${kind}-${index}`} />
                            )),
                          )}
                        </span>
                      )}
                    </button>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="calendar-legend" aria-label="일정 종류 필터">
        {SCHEDULE_TYPES.map(({kind, label}) => (
          <button className={`calendar-filter${enabledTypes.has(kind) ? ' is-active' : ''}`} type="button" key={kind}
            aria-pressed={enabledTypes.has(kind)} onClick={() => onToggleType(kind)}>
            <span className={`event-calendar-dot dot-${kind}`} aria-hidden="true" />{label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default function JLiveHome() {
  const [search, setSearch] = useState('');
  const [concerts, setConcerts] = useState<Concert[]>([]);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [dataError, setDataError] = useState(false);
  const [selectedDate, setSelectedDate] = useState<ISODateString | null>(null);
  const [selectedId, setSelectedId] = useState('');
  const [selectedKind, setSelectedKind] = useState<ScheduleKind>('concert');
  const [detailOpen, setDetailOpen] = useState(false);
  const [enabledTypes, setEnabledTypes] = useState<Set<ScheduleKind>>(() => new Set(['concert', 'ticket', 'presale', 'festival']));
  const [shareMessage, setShareMessage] = useState('');

  useEffect(() => {
    let active = true;
    fetch(`${import.meta.env.BASE_URL}data/mockEvents.json`)
      .then(response => {
        if (!response.ok) throw new Error('공연 일정을 불러오지 못했습니다.');
        return response.json();
      })
      .then((data: {events: RawMockEvent[]}) => {
        if (!active) return;
        const nextConcerts = mapMockEvents(data.events);
        const firstUpcoming = nextConcerts.find(concert => concert.date >= kstDateKey()) ?? nextConcerts[0];
        setConcerts(nextConcerts);
        setSelectedDate(firstUpcoming?.date ?? null);
        setSelectedId(firstUpcoming?.id ?? '');
      })
      .catch(() => { if (active) setDataError(true); })
      .finally(() => { if (active) setDataLoaded(true); });
    return () => { active = false; };
  }, []);

  const allEntries = useMemo(() => makeScheduleEntries(concerts), [concerts]);
  const visibleEntries = useMemo(
    () => allEntries.filter(entry => enabledTypes.has(entry.kind)),
    [allEntries, enabledTypes],
  );

  const filteredConcerts = useMemo(() => {
    const query = search.trim().toLocaleLowerCase();
    return visibleEntries.filter(entry => {
      const concert = entry.concert;
      const matchesQuery =
        !query ||
        `${concert.artist} ${concert.venue} ${concert.date} ${entry.date} ${entry.kind}`
          .toLocaleLowerCase()
          .includes(query);
      const matchesDate = !selectedDate || entry.date === selectedDate;
      return matchesQuery && (query ? true : matchesDate);
    });
  }, [search, selectedDate, visibleEntries]);

  const selectedEntry = filteredConcerts.find(entry => entry.concert.id === selectedId && entry.kind === selectedKind && entry.date === selectedDate)
    ?? filteredConcerts.find(entry => entry.concert.id === selectedId && entry.kind === selectedKind)
    ?? filteredConcerts[0];
  const selectedConcert = selectedEntry?.concert;
  const selectedKindForDetail = selectedEntry?.kind ?? selectedKind;
  const selectedSources = selectedConcert?.sources ?? (selectedConcert?.ticketUrl ? [selectedConcert.ticketUrl] : []);
  const selectedSongs = selectedConcert?.songs ?? [];
  const today = kstDateKey();
  const upcomingSeries = new Map<string, {concerts: Concert[]; dates: ISODateString[]}>();
  concerts.forEach(concert => {
    const dates = concert.isFestival && concert.festivalDates?.length
      ? concert.festivalDates.filter(date => date >= today)
      : concert.date >= today ? [concert.date] : [];
    if (!dates.length) return;
    const key = concert.ticketUrl
      ? `${concert.artist.trim().toLocaleLowerCase()}|${concert.venue.trim().toLocaleLowerCase()}|${concert.ticketUrl}`
      : concert.id;
    const group = upcomingSeries.get(key) ?? {concerts: [], dates: []};
    group.concerts.push(concert);
    group.dates.push(...dates);
    upcomingSeries.set(key, group);
  });
  const featuredWeekendConcerts = [...upcomingSeries.values()]
    .map(group => {
      const dates = [...new Set(group.dates)].sort();
      const firstDate = dates[0];
      const concert = group.concerts.find(item => nextConcertDate(item, today) === firstDate) ?? group.concerts[0];
      return {concert, date: firstDate, dates};
    })
    .sort((left, right) => left.date.localeCompare(right.date)
      || formatCompactTime(left.concert.time).localeCompare(formatCompactTime(right.concert.time)))
    .slice(0, 3);
  const listTitle = search.trim()
    ? `검색 결과 ${filteredConcerts.length}건`
    : selectedDate
      ? `${formatDate(selectedDate)} 일정`
      : '전체 일정';
  const emptyTitle = !dataLoaded
    ? '공연 일정을 불러오는 중입니다'
    : dataError
      ? '공연 일정을 불러오지 못했습니다'
      : search.trim()
        ? '일치하는 공연이 없습니다'
        : enabledTypes.size === 0
          ? '일정 종류를 선택해 주세요'
          : selectedDate
            ? '이 날짜에 등록된 일정이 없습니다'
            : '확인된 공연 일정이 없습니다';
  const emptyCopy = dataError
    ? '잠시 후 다시 열어 주세요.'
    : search.trim()
      ? '아티스트명, 공연장 또는 날짜를 바꿔 검색해 보세요.'
      : '달력에서 다른 날짜를 선택하거나 일정 종류 필터를 바꿔 보세요.';

  const toggleScheduleType = (kind: ScheduleKind) => {
    setDetailOpen(false);
    setEnabledTypes(current => {
      const next = new Set(current);
      if (next.has(kind)) next.delete(kind);
      else next.add(kind);
      return next;
    });
  };

  const selectCalendarDate = (date: ISODateString) => {
    setSelectedDate(date);
    setDetailOpen(false);
    const firstEntry = visibleEntries.find(entry => entry.date === date);
    if (firstEntry) {
      setSelectedId(firstEntry.concert.id);
      setSelectedKind(firstEntry.kind);
    }
  };

  const shareCalendar = async () => {
    try {
      if (navigator.share) await navigator.share({title: 'J-LIVE 공연 일정', url: window.location.href});
      else if (navigator.clipboard) {
        await navigator.clipboard.writeText(window.location.href);
        setShareMessage('일정 링크를 복사했어요.');
      } else setShareMessage('주소창에서 링크를 복사해 주세요.');
    } catch {
      setShareMessage('공유를 취소했어요.');
    }
    window.setTimeout(() => setShareMessage(''), 2400);
  };

  return (
    <Theme theme={jliveMockupTheme} mode="dark">
      <InternationalizationProvider locale="ko-KR" messages={{'ko-KR': koKR}}>
      <Layout
        header={
          <LayoutHeader hasDivider padding={4}>
            <HStack as="nav" className="site-nav" hAlign="between" vAlign="center" gap={4}>
              <a className="brand" href="#top" aria-label="J-LIVE 홈">
                <b className="brand-mark">J</b>
                <strong>J-LIVE</strong>
                <small>LIVE IN KOREA</small>
              </a>
              <HStack as="ul" className="nav-links" gap={4}>
                <li><a href="#calendar">공연 찾기</a></li>
                <li><a href="#schedule">예매 일정</a></li>
                <li><a href="#guide">공연 준비</a></li>
              </HStack>
              <Button label="일정 공유" onClick={shareCalendar} variant="secondary" size="sm" />
            </HStack>
          </LayoutHeader>
        }
        content={
          <LayoutContent padding={5}>
            <VStack as="main" className="page-shell" gap={6}>
              <VStack as="section" className="hero" gap={4}>
                <p className="eyebrow">J-POP LIVE CALENDAR · {kstDateKey().slice(0, 4)}</p>
                <VStack className="hero-row" gap={1}>
                  <h1 id="top">좋아하는 무대,<br />날짜부터 찾기</h1>
                  <p className="hero-copy">공연일과 예매처를 한 곳에서 확인하고, 원하는 날짜의 공연을 바로 찾아보세요.</p>
                </VStack>
                <TextInput
                  label="공연 검색"
                  placeholder="아티스트·공연장·날짜"
                  value={search}
                  onChange={value => { setSearch(value); setDetailOpen(false); }}
                  size="lg"
                  width="100%"
                />
              </VStack>

              {featuredWeekendConcerts.length ? <section className="weekend-spotlight" aria-label="다가오는 주말 공연">
                <p className="eyebrow">UPCOMING WEEKEND</p>
                <div className="weekend-list">{featuredWeekendConcerts.map(({concert, date, dates}) => {
                  const kind: ScheduleKind = concert.isFestival ? 'festival' : 'concert';
                  return (
                    <button className="weekend-item" type="button" key={concert.id} onClick={() => { setSelectedDate(date); setSelectedId(concert.id); setSelectedKind(kind); setDetailOpen(true); }}>
                      <img className="artist-avatar" src={concert.image ?? createArtistArtwork(concert.artist)} alt="" />
                      <span>
                        <strong><span className="weekend-artist">{concert.artist}</span><span className="countdown-badge">{formatCountdown(concert.date)}</span></strong>
                        <small>{`${formatSeriesDates(dates)} · ${concert.isFestival ? '페스티벌 · ' : ''}${concert.venue}`}</small>
                      </span>
                      <b aria-hidden="true">↗</b>
                    </button>
                  );
                })}</div>
              </section> : null}

              <HStack className="browse-heading" hAlign="between" vAlign="end" gap={4}>
                <VStack gap={0.5}>
                  <p className="eyebrow">FIND YOUR NEXT SHOW</p>
                  <h2>공연 일정</h2>
                </VStack>
                <button
                  className="clear-date"
                  type="button"
                  onClick={() => { setSelectedDate(null); setDetailOpen(false); }}
                  aria-label="날짜 선택 해제하고 전체 예정 공연 보기">
                  전체 일정 보기 <b aria-hidden="true">↗</b>
                </button>
              </HStack>

              <section className="browse-grid" aria-label="달력과 공연 목록">
                <section className="calendar-column" id="calendar" aria-labelledby="calendar-title">
                  <Card padding={4}>
                    <VStack gap={3}>
                      <HStack className="section-head" hAlign="between" vAlign="center">
                        <VStack gap={0.5}>
                          <h3 id="calendar-title">JPOP 캘린더</h3>
                        </VStack>
                      </HStack>
                      <ConcertCalendar
                        key={selectedDate?.slice(0, 7) ?? '2026-11'}
                        entries={visibleEntries}
                        enabledTypes={enabledTypes}
                        selectedDate={selectedDate}
                        onSelectDate={selectCalendarDate}
                        onToggleType={toggleScheduleType}
                      />
                    </VStack>
                  </Card>
                </section>

                <section className="schedule-column" id="schedule" aria-labelledby="schedule-title">
                  <HStack className="schedule-top" hAlign="between" vAlign="center" gap={3}>
                    <VStack gap={0.5}>
                      <p className="eyebrow">UPCOMING SHOWS</p>
                      <h3 id="schedule-title">{listTitle}</h3>
                    </VStack>
                    <span className="result-count">{filteredConcerts.length} 일정</span>
                  </HStack>
                  {filteredConcerts.length > 0 ? (
                    <List density="compact" header="공연별 일정과 장소">
                      {filteredConcerts.map(({concert, kind, date}) => (
                        <ListItem
                          key={`${concert.id}-${kind}-${date}`}
                          label={concert.artist}
                          description={concert.isFestival
                            ? `${formatCompactDate(date)} · 3일 행사 · ${concert.venue}`
                            : kind === 'concert'
                              ? `${formatCompactDate(date)}${concert.time ? ` · ${formatCompactTime(concert.time)}` : ' · 시간 미확인'} · ${concert.venue}`
                              : `${SCHEDULE_TYPES.find(item => item.kind === kind)?.label} ${formatCompactDate(date)} · 공연 ${formatCompactDate(concert.date)}${concert.time ? ` ${formatCompactTime(concert.time)}` : ''} · ${concert.venue}`}
                          descriptionLines={2}
                          startContent={<img className="artist-avatar" src={concert.image ?? createArtistArtwork(concert.artist)} alt={`${concert.artist} 이미지`} />}
                          endContent={<b className={concert.isFestival ? 'festival-label' : 'row-price'}>{concert.isFestival ? 'FESTIVAL' : formatPriceSummary(concert)}</b>}
                          onClick={() => {
                            const sameEntry = concert.id === selectedId && kind === selectedKind && date === selectedDate;
                            setSelectedId(concert.id);
                            setSelectedKind(kind);
                            setSelectedDate(date);
                            setDetailOpen(open => sameEntry ? !open : true);
                          }}
                          isSelected={detailOpen && concert.id === selectedConcert?.id && kind === selectedEntry?.kind}
                        />
                      ))}
                    </List>
                  ) : (
                    <Card variant="muted" padding={4}>
                      <VStack className="empty-state" gap={2}>
                        <h4>{emptyTitle}</h4>
                        <p>{emptyCopy}</p>
                        {search.trim() ? <Button label="검색어 지우기" variant="secondary" onClick={() => { setSearch(''); setDetailOpen(false); }} /> : null}
                      </VStack>
                    </Card>
                  )}

                  {detailOpen && selectedConcert && (
                    <Card variant="muted" padding={4}>
                      <VStack className="selected-detail" gap={2}>
                        <HStack className="detail-topline" hAlign="between" vAlign="center">
                          <p className="eyebrow">SELECTED SHOW</p>
                          <button className="detail-collapse" type="button" onClick={() => setDetailOpen(false)} aria-label="상세 정보 접기">접기 ↑</button>
                        </HStack>
                        <div className="detail-artist-heading">
                          <img className="detail-artist-image" src={selectedConcert.image ?? createArtistArtwork(selectedConcert.artist)} alt={`${selectedConcert.artist} 이미지`} />
                          <div><h4>{selectedConcert.artist}</h4><span className={`detail-kind kind-${selectedKindForDetail}`}>{SCHEDULE_TYPES.find(item => item.kind === selectedKindForDetail)?.label}</span></div>
                        </div>
                        <p>{formatDate(selectedKindForDetail === 'festival' && selectedEntry ? selectedEntry.date : selectedConcert.date)}{selectedConcert.time ? ` · ${selectedConcert.time}` : ' · 시작 시간 미확인'}</p>
                        <p>{selectedConcert.venue} · {formatPriceSummary(selectedConcert)}</p>
                        {selectedConcert.isFestival && selectedConcert.festivalDates?.length ? <p>축제 기간 {formatDate(selectedConcert.festivalDates[0])}–{formatDate(selectedConcert.festivalDates[selectedConcert.festivalDates.length - 1])}</p> : null}
                        {selectedConcert.posterImage ? <img className="detail-festival-poster" src={selectedConcert.posterImage} alt="WONDERLIVET 2026 공식 라인업 포스터" /> : null}
                        {selectedConcert.seatPrices?.length ? (
                          <dl className="seat-price-list">
                            {selectedConcert.seatPrices.map(item => <div key={`${item.name}-${item.price}`}><dt>{item.name}</dt><dd>{formatPrice(item.price)}</dd></div>)}
                          </dl>
                        ) : null}
                        <dl className="selected-facts">
                          {selectedConcert.presaleDate && (
                            <div><dt>선예매</dt><dd>{formatDate(selectedConcert.presaleDate)} {selectedConcert.presaleTime}</dd></div>
                          )}
                          <div>
                            <dt>{selectedConcert.ticketLabel ?? '일반예매'}</dt>
                            <dd>{selectedConcert.ticketDate
                              ? `${formatDate(selectedConcert.ticketDate)} ${selectedConcert.ticketTime ?? ''}`
                              : '일정 미확인'}</dd>
                          </div>
                          <div>
                            <dt>마지막 확인</dt>
                            <dd>{formatAuditDate(selectedConcert.verifiedAt)}</dd>
                          </div>
                        </dl>
                        {selectedConcert.ticketUrl ? <a className="ticket-link" href={selectedConcert.ticketUrl} target="_blank" rel="noreferrer">
                          {selectedConcert.ticketVendor ?? '공식 예매처'} 최신 정보 확인 <b aria-hidden="true">↗</b>
                        </a> : null}
                        <div className="detail-resource-links">
                          {selectedSources.map((url, index) => <a href={url} key={url} target="_blank" rel="noreferrer">공식 출처 {index + 1} ↗</a>)}
                          <a href={selectedConcert.festivalPageUrl ?? `https://j-live.kr/calendar/events/${encodeURIComponent(selectedConcert.id)}`} target="_blank" rel="noreferrer">공연 상세 페이지 ↗</a>
                        </div>
                        {selectedSongs.length ? (
                          <section className="selected-songs" aria-label="대표곡 바로 듣기">
                            <h5>대표곡 바로 듣기</h5>
                            <ul>{selectedSongs.map(song => <li key={song.url}><a href={song.url} target="_blank" rel="noreferrer">▶ {song.title}</a></li>)}</ul>
                          </section>
                        ) : null}
                      </VStack>
                    </Card>
                  )}
                </section>
              </section>

              <footer className="feature-links" id="guide">
                <p>공연을 찾은 다음 필요한 정보</p>
                <nav aria-label="J-LIVE 공연 준비 안내">
                  <a href="https://j-live.kr/calendar/guides/standing-concert">스탠딩 공연 가이드</a>
                  <a href="https://j-live.kr/calendar/guides/venues/">공연장 가이드</a>
                  <a href="https://j-live.kr/calendar/guides/verification">공연 정보 검증 기준</a>
                </nav>
              </footer>
              <footer className="site-footer">
                <nav aria-label="사이트 정보">
                  <a href="https://j-live.kr/calendar/about.html">소개</a>
                  <a href="https://j-live.kr/calendar/contact.html">문의</a>
                  <a href="https://j-live.kr/calendar/privacy.html">개인정보처리방침</a>
                  <a href="https://j-live.kr/calendar/terms.html">이용약관</a>
                  <a href="https://j-live.kr/calendar/corrections.html">정보 수정 요청</a>
                </nav>
                <p>J-LIVE는 공연 주최사 또는 예매처가 아닙니다. 예매 전 공식 페이지에서 최신 정보를 확인하세요.</p>
              </footer>
              <p className="share-status" role="status" aria-live="polite">{shareMessage}</p>
            </VStack>
          </LayoutContent>
        }
      />
      </InternationalizationProvider>
    </Theme>
  );
}
