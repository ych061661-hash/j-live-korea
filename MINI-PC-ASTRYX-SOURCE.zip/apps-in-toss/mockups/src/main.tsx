import {createRoot} from 'react-dom/client';
import JLiveHome from './JLiveHome';
import './styles.css';

createRoot(document.getElementById('root')!).render(<JLiveHome />);
