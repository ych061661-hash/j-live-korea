// Written by `astryx experimental theme editor` after every build of themes/jlive-mockup/; do not edit it here. Change the theme with the editor. 

/** @type {import('@astryxdesign/cli/authoring').ThemeDoc} */
export default {
  type: 'theme',
  name: "jlive-mockup",
  displayName: "jlive-mockup",
  description: "The jlive-mockup theme, made with the theme editor (themes/jlive-mockup/).",
  maintained: false,
};
