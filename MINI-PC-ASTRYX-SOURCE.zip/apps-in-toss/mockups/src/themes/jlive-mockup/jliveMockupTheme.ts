// Written by `astryx experimental theme editor` after every build of themes/jlive-mockup/; do not edit it here. Change the theme with the editor. 
export {jliveMockupTheme} from './jlive-mockup';
